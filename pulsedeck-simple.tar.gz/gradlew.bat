@if "%DEBUG%" == "" @echo off
@rem ##########################################################################
@rem Gradle wrapper script for Windows
@rem ##########################################################################

setlocal enabledelayedexpansion

set GRADLE_VERSION=8.1
set GRADLE_HOME=%USERPROFILE%\.gradle
set GRADLE_ZIP=%GRADLE_HOME%\gradle-%GRADLE_VERSION%-bin.zip
set GRADLE_DIR=%GRADLE_HOME%\gradle-%GRADLE_VERSION%

if not exist "%GRADLE_DIR%" (
    echo Downloading Gradle %GRADLE_VERSION%...
    if not exist "%GRADLE_HOME%" mkdir "%GRADLE_HOME%"
    
    set GRADLE_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip
    
    if exist "%ProgramFiles%\PowerShell\Core\pwsh.exe" (
        "%ProgramFiles%\PowerShell\Core\pwsh.exe" -Command "Invoke-WebRequest -Uri '%GRADLE_URL%' -OutFile '%GRADLE_ZIP%'" || (
            echo Failed to download Gradle
            exit /b 1
        )
    ) else if exist "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" (
        "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -Command "Invoke-WebRequest -Uri '%GRADLE_URL%' -OutFile '%GRADLE_ZIP%'" || (
            echo Failed to download Gradle
            exit /b 1
        )
    ) else (
        echo Error: PowerShell not found. Please download Gradle manually from:
        echo %GRADLE_URL%
        exit /b 1
    )
    
    echo Extracting Gradle...
    powershell -Command "Expand-Archive -Path '%GRADLE_ZIP%' -DestinationPath '%GRADLE_HOME%'" || (
        echo Failed to extract Gradle
        exit /b 1
    )
    del /f /q "%GRADLE_ZIP%"
    echo Gradle %GRADLE_VERSION% installed
)

"%GRADLE_DIR%\bin\gradle.bat" %*
