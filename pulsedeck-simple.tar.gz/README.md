# PulseDeck Launcher v2.0

A beautiful Android launcher with split-panel design: weather on the left, live sports scores and news on the right.

## Features

- ☀️ **Live Weather** — Real-time temperature, humidity, wind, visibility (OpenWeatherMap API)
- 🏆 **Live Sports** — MLB and NBA scores (SportsData.io API)
- 📰 **Local News** — Top headlines filtered by location (NewsAPI)
- 🔄 **30-Second Updates** — Auto-refresh for live data
- 📍 **Location-Based** — Requests device GPS for accurate weather and local news
- 🎨 **Flat Design** — Black typography, card-based layout, no gradients

## Quick Start

### Prerequisites

- **Java Development Kit (JDK) 11+**
  - [Download JDK](https://www.oracle.com/java/technologies/downloads/)
  - Verify: `java -version`

- **Android SDK** (optional, for ADB deployment)
  - [Download Android Studio](https://developer.android.com/studio) (includes SDK + Gradle)

- **Gradle 8.1+** (if not using Android Studio)
  - Will be auto-downloaded via Gradle wrapper

### Build the APK

#### Option A: Using Android Studio (Recommended)

1. Open Android Studio
2. Select **File → Open** and choose the `pulsedeck-rebuild` folder
3. Android Studio will auto-detect and sync the project
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`

#### Option B: Using Gradle from Command Line

```bash
cd pulsedeck-rebuild

# Build debug APK
./gradlew clean build

# Or full build with release signing (requires keystore)
./gradlew clean bundleRelease
```

#### Option C: Using Build Script

```bash
cd pulsedeck-rebuild
chmod +x build_apk.sh
./build_apk.sh
```

### Configure API Keys

Before running the app, you must register for free API keys:

#### 1. OpenWeatherMap (Weather)
- Go to https://openweathermap.org/api
- Sign up for free account
- Copy your API key
- Edit `app/src/main/java/com/sportsplusl/launcher/MainActivity.kt`
- Find: `private val WEATHER_API_KEY = "YOUR_OPENWEATHERMAP_KEY"`
- Replace with your key

#### 2. NewsAPI (News Headlines)
- Go to https://newsapi.org
- Sign up for free account
- Copy your API key
- Edit `MainActivity.kt`
- Find: `private val NEWS_API_KEY = "YOUR_NEWSAPI_KEY"`
- Replace with your key

#### 3. SportsData.io (Sports Scores)
- Go to https://sportsdata.io/developers
- Sign up for free account
- Copy your API key
- Edit `MainActivity.kt`
- Find: `private val SPORTS_API_KEY = "YOUR_SPORTSDATA_KEY"`
- Replace with your key

### Install on Device

```bash
# Connect Android device via USB
# Enable Developer Mode and USB Debugging in device settings

adb install -r app/build/outputs/apk/debug/app-debug.apk

# Or use the build script
./build_apk.sh  # Will prompt to deploy
```

### Grant Permissions

When you first launch PulseDeck:
1. Tap **Allow** for location permissions (needed for weather & local news)
2. App requires INTERNET permission (auto-granted)

## Project Structure

```
pulsedeck-rebuild/
├── app/
│   ├── src/main/
│   │   ├── java/com/sportsplusl/launcher/
│   │   │   └── MainActivity.kt               # Main activity & API logic
│   │   ├── AndroidManifest.xml               # Permissions & config
│   │   └── res/
│   │       ├── layout/
│   │       │   └── activity_main.xml         # Split-panel UI layout
│   │       ├── drawable/
│   │       │   ├── card_background.xml       # Card style
│   │       │   ├── toggle_button_*.xml       # Toggle styles
│   │       │   ├── ic_launcher.xml           # App icon
│   │       │   └── ic_*.xml                  # Weather icons
│   │       └── values/
│   │           └── strings.xml               # String resources
│   ├── build.gradle                          # App config
│   └── proguard-rules.pro                    # Code shrinking rules
├── build.gradle                              # Root config
├── settings.gradle                           # Project structure
├── gradlew                                   # Gradle wrapper (auto-downloaded)
└── README.md                                 # This file
```

## Customization

### Change Default Location

Edit `MainActivity.kt`:
```kotlin
private var currentLat = 39.9526  // Change to your latitude
private var currentLon = -75.1652 // Change to your longitude
```

### Adjust Refresh Rate

Edit `MainActivity.kt`, find `startPeriodicUpdates()`:
```kotlin
handler.postDelayed(this, 30000) // Change 30000 milliseconds to desired interval
```

### Change News Category

Edit the news fetch URL:
```kotlin
// Current: general
// Available: business, entertainment, health, science, sports, technology
val url = "https://newsapi.org/v2/top-headlines?country=us&category=sports&apiKey=$NEWS_API_KEY"
```

### Change Sports Leagues

Edit `fetchSports()` to add NHL, NFL, etc.:
```kotlin
// Current: MLB + NBA
// Add NHL:
val nhlUrl = "https://api.sportsdata.io/v3/nhl/scores/json/ScoresBasic?key=$SPORTS_API_KEY"
```

## Troubleshooting

### Build fails: "Cannot find Gradle"
- Install Gradle 8.1+ from https://gradle.org/releases/
- Or use: `./gradlew` (auto-downloads Gradle)

### Build fails: "Cannot find Android SDK"
- Install Android Studio or Android SDK Platform Tools
- Set `ANDROID_HOME` environment variable

### APK installs but crashes
- Check Logcat: `adb logcat | grep PulseDeck`
- Verify API keys are correctly set in `MainActivity.kt`
- Ensure device has internet connection

### Weather/Sports/News empty
- Verify API keys in `MainActivity.kt`
- Check API rate limits (may be throttled if testing repeatedly)
- Ensure device has active internet
- Check Logcat for API errors

### Location always shows default
- Grant location permission in Settings → Apps → PulseDeck
- Enable GPS on device
- Wait 30+ seconds for GPS lock (first time)

## API Rate Limits

- **OpenWeatherMap Free**: 1,000 calls/day (refreshes every 30 sec = ~2,880 calls/day if always on)
- **NewsAPI Free**: 100 requests/day (refreshes every 30 sec only when news view active)
- **SportsData.io Free**: 500 requests/month (refreshes every 30 sec only when sports view active)

For production, consider upgrading to paid tiers or implementing local caching.

## Release Build

To create a production APK for deployment:

```bash
# Generate release build (requires signing key)
./gradlew clean bundleRelease

# Or with automatic signing (for testing):
./gradlew clean assembleRelease
```

For app store submission, you'll need:
1. A signed APK or AAB (Android App Bundle)
2. A keystore file with your signing key
3. See [Android App Signing](https://developer.android.com/studio/publish/app-signing)

## Dependencies

- **Kotlin 1.9.10** — Android development language
- **AndroidX AppCompat 1.6.1** — UI compatibility
- **Coroutines 1.7.3** — Async networking without ANR
- **org.json 20231013** — JSON parsing

## License

This launcher is provided as-is. Use freely for personal projects.

## Support

For issues or questions:
1. Check the Troubleshooting section above
2. Review API documentation:
   - [OpenWeatherMap API](https://openweathermap.org/api)
   - [NewsAPI Docs](https://newsapi.org/docs)
   - [SportsData.io API](https://sportsdata.io/developers)
3. Check Android logs: `adb logcat | grep PulseDeck`

## Next Steps

Enhancements you can add:
- [ ] Settings Activity for API key input
- [ ] Local caching with Room database
- [ ] Push notifications for sports alerts
- [ ] Custom sports league selection
- [ ] Dark mode support
- [ ] Material Design 3 upgrade
- [ ] Widget support (home screen widgets)

---

**Built with Kotlin + Android SDK 34**

Happy building! 🚀
