# PulseDeck - Quick Start Guide

## 5-Minute Setup

### Step 1: Get API Keys (2 minutes)

Register for free accounts at:

1. **OpenWeatherMap** → https://openweathermap.org/api
   - Sign up, copy your API key
   - Limit: 1,000 calls/day (free)

2. **NewsAPI** → https://newsapi.org
   - Sign up, copy your API key
   - Limit: 100 requests/day (free)

3. **SportsData.io** → https://sportsdata.io/developers
   - Sign up, copy your API key
   - Limit: 500 requests/month (free)

### Step 2: Update API Keys (1 minute)

Open `app/src/main/java/com/sportsplusl/launcher/MainActivity.kt` and replace:

```kotlin
private val WEATHER_API_KEY = "YOUR_OPENWEATHERMAP_KEY"  // ← Replace this
private val NEWS_API_KEY = "YOUR_NEWSAPI_KEY"            // ← Replace this
private val SPORTS_API_KEY = "YOUR_SPORTSDATA_KEY"       // ← Replace this
```

### Step 3: Build (2 minutes)

**Option A: Using Android Studio**
- Open folder → **Build → Build APK(s)**
- Done! APK at `app/build/outputs/apk/debug/app-debug.apk`

**Option B: Command Line**
```bash
cd pulsedeck-rebuild
./gradlew build
```

**Option C: Automated**
```bash
chmod +x build_apk.sh
./build_apk.sh
```

### Step 4: Install on Device

```bash
# Connect device via USB + enable USB Debugging

adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Done! ✅

---

## First Run

1. App requests location permission → **Tap Allow**
2. Wait 30 seconds for weather/sports/news to load
3. Tap **Sports** or **News** to toggle views

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Cannot find gradle" | Install Java 11+ first: `java -version` |
| Build fails | Delete `app/build/` folder, try again |
| No data showing | Check API keys in MainActivity.kt |
| Crashes on launch | Check Logcat: `adb logcat \| grep PulseDeck` |
| Location always default | Grant location permission in Settings |

---

## For Windows Users

Use `gradlew.bat` instead of `./gradlew`:

```bash
gradlew.bat build
```

---

## Need Help?

See full README.md for detailed customization and troubleshooting.

---

**Ready? Start with the API keys above! 🚀**
