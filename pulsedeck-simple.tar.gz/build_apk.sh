#!/bin/bash
# PulseDeck APK Build Script
# Run this script to build the PulseDeck launcher APK

set -e

echo "================================================"
echo "PulseDeck APK Builder"
echo "================================================"

# Check for required tools
check_requirements() {
    echo "[*] Checking requirements..."
    
    if ! command -v gradle &> /dev/null; then
        echo "[!] Gradle not found. Install from https://gradle.org/releases/"
        echo "[!] Or use the Android Studio Gradle wrapper:"
        echo "    ./gradlew build"
        exit 1
    fi
    
    if ! command -v java &> /dev/null; then
        echo "[!] Java not found. Install JDK 11 or higher"
        exit 1
    fi
    
    JAVA_VERSION=$(java -version 2>&1 | grep -oP '(?<=")[^"]*(?=")' | head -1)
    echo "[✓] Java version: $JAVA_VERSION"
    echo "[✓] Gradle found: $(gradle --version | head -1)"
}

# Setup Gradle wrapper
setup_gradle_wrapper() {
    echo "[*] Setting up Gradle wrapper..."
    
    if [ ! -f "gradle/wrapper/gradle-wrapper.jar" ]; then
        mkdir -p gradle/wrapper
        
        # Download gradle wrapper
        GRADLE_VERSION="8.1"
        WRAPPER_JAR_URL="https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-wrapper.zip"
        
        echo "[*] Downloading Gradle wrapper..."
        wget -q "$WRAPPER_JAR_URL" -O /tmp/gradle-wrapper.zip || \
        curl -s "$WRAPPER_JAR_URL" -o /tmp/gradle-wrapper.zip
        
        unzip -q /tmp/gradle-wrapper.zip gradle/wrapper -d .
        rm /tmp/gradle-wrapper.zip
        chmod +x gradlew
        echo "[✓] Gradle wrapper installed"
    fi
}

# Build the APK
build_apk() {
    echo "[*] Building PulseDeck APK..."
    
    if [ -f "./gradlew" ]; then
        ./gradlew clean build --stacktrace
    else
        gradle clean build --stacktrace
    fi
    
    echo "[✓] Build completed!"
}

# Deploy to device
deploy_to_device() {
    echo "[*] Checking for connected Android devices..."
    
    if ! command -v adb &> /dev/null; then
        echo "[!] ADB not found. Install Android SDK Platform Tools"
        echo "[*] APK built at: app/build/outputs/apk/debug/app-debug.apk"
        return
    fi
    
    DEVICE_COUNT=$(adb devices | grep -v "List of attached" | grep -v "^$" | wc -l)
    
    if [ "$DEVICE_COUNT" -eq 0 ]; then
        echo "[!] No Android device connected"
        echo "[*] APK built at: app/build/outputs/apk/debug/app-debug.apk"
        echo "[*] To install manually:"
        echo "    adb install -r app/build/outputs/apk/debug/app-debug.apk"
        return
    fi
    
    echo "[✓] Found $DEVICE_COUNT device(s)"
    echo "[*] Installing APK..."
    adb install -r app/build/outputs/apk/debug/app-debug.apk
    
    echo "[✓] Installation complete!"
    echo "[*] Launching PulseDeck..."
    adb shell am start -n com.sportsplusl.launcher/.MainActivity
}

# Main
main() {
    check_requirements
    setup_gradle_wrapper
    build_apk
    
    read -p "[?] Deploy to connected device? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        deploy_to_device
    fi
    
    echo ""
    echo "================================================"
    echo "[✓] Build successful!"
    echo "================================================"
}

main "$@"
