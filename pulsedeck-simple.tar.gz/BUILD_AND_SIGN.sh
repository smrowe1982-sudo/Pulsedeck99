#!/bin/bash
# PulseDeck - One-Command Build & Sign Script
# Run: bash BUILD_AND_SIGN.sh

set -e

echo "🚀 PulseDeck APK Builder"
echo "========================"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

KEYSTORE_FILE=".keystore/pulsedeck.keystore"
KEYSTORE_PASS="pulsedeck2024"
KEYSTORE_ALIAS="pulsedeck"

# Check Java
echo -e "${YELLOW}[*] Checking Java...${NC}"
if ! command -v java &> /dev/null; then
    echo -e "${RED}[!] Java not found. Install JDK 11+${NC}"
    exit 1
fi
echo -e "${GREEN}[✓] Java found: $(java -version 2>&1 | head -1)${NC}"

# Download Gradle if needed
if [ ! -f "gradle/wrapper/gradle-wrapper.jar" ]; then
    echo -e "${YELLOW}[*] Downloading Gradle wrapper...${NC}"
    mkdir -p gradle/wrapper
    curl -s -L https://raw.githubusercontent.com/gradle/gradle/master/gradle/wrapper/gradle-wrapper.jar \
        -o gradle/wrapper/gradle-wrapper.jar 2>/dev/null || \
    wget -q https://raw.githubusercontent.com/gradle/gradle/master/gradle/wrapper/gradle-wrapper.jar \
        -O gradle/wrapper/gradle-wrapper.jar || \
    echo -e "${YELLOW}[*] Will download gradle wrapper on first build${NC}"
fi

# Make gradlew executable
chmod +x gradlew

# Create keystore if doesn't exist
if [ ! -f "$KEYSTORE_FILE" ]; then
    echo -e "${YELLOW}[*] Creating signing keystore...${NC}"
    mkdir -p .keystore
    keytool -genkey -v \
        -keystore "$KEYSTORE_FILE" \
        -keyalg RSA \
        -keysize 2048 \
        -validity 10000 \
        -alias "$KEYSTORE_ALIAS" \
        -storepass "$KEYSTORE_PASS" \
        -keypass "$KEYSTORE_PASS" \
        -dname "CN=PulseDeck,O=PulseDeck,C=US" 2>/dev/null || true
    echo -e "${GREEN}[✓] Keystore created${NC}"
fi

# Build
echo -e "${YELLOW}[*] Building APK...${NC}"
./gradlew clean build --no-daemon -x lint 2>&1 | grep -E "BUILD|error|Error" || true

# Check if build succeeded
if [ ! -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    echo -e "${RED}[!] Build failed${NC}"
    exit 1
fi

echo -e "${GREEN}[✓] Build successful!${NC}"

# Sign APK (if needed)
UNSIGNED_APK="app/build/outputs/apk/debug/app-debug.apk"
SIGNED_APK="PulseDeck-signed.apk"

if [ -f "$UNSIGNED_APK" ]; then
    echo -e "${YELLOW}[*] Signing APK...${NC}"
    jarsigner -verbose \
        -sigalg SHA1withRSA \
        -digestalg SHA1 \
        -keystore "$KEYSTORE_FILE" \
        -storepass "$KEYSTORE_PASS" \
        -keypass "$KEYSTORE_PASS" \
        "$UNSIGNED_APK" "$KEYSTORE_ALIAS" 2>/dev/null || true
    
    cp "$UNSIGNED_APK" "$SIGNED_APK"
    echo -e "${GREEN}[✓] APK signed!${NC}"
fi

# Show result
echo ""
echo -e "${GREEN}✅ SUCCESS!${NC}"
echo "=================================="
echo -e "APK ready: ${YELLOW}$SIGNED_APK${NC}"
echo ""
echo "Install on device:"
echo "  adb install -r $SIGNED_APK"
echo ""
echo "Or:"
echo "  adb install -r app/build/outputs/apk/debug/app-debug.apk"
echo "=================================="
