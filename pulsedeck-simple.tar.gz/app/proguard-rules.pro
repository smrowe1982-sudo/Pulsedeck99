# Retrofit
-keep class retrofit2.** { *; }
-keepattributes Signature
-keepattributes Exceptions

# OkHttp
-keep class okhttp3.** { *; }

# Kotlin coroutines
-keep class kotlinx.coroutines.** { *; }

# JSON
-keep class org.json.** { *; }

# Keep your application classes
-keep class com.sportsplusl.launcher.** { *; }

# Keep view constructors for layout inflation
-keepclasseswithmembers class * {
    public <init>(android.content.Context, android.util.AttributeSet);
}

# Keep activity names
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver

# Keep API classes
-keep class com.sportsplusl.launcher.MainActivity { *; }
