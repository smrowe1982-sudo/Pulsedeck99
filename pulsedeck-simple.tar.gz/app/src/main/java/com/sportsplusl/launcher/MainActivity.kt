package com.sportsplusl.launcher

import android.os.Bundle
import android.widget.Button
import android.widget.ScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import android.graphics.Color

class MainActivity : AppCompatActivity() {
    private var isShowingSports = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        setupToggleButtons()
        updateWeatherUI()
        updateSportsUI()
        updateNewsUI()
    }

    private fun setupToggleButtons() {
        val btnSports = findViewById<Button>(R.id.btn_sports)
        val btnNews = findViewById<Button>(R.id.btn_news)
        val panelTitle = findViewById<TextView>(R.id.panel_title)

        btnSports?.setOnClickListener {
            if (!isShowingSports) {
                isShowingSports = true
                updateToggleVisuals(btnSports, btnNews)
                switchView(true)
                panelTitle?.text = "Live games"
            }
        }

        btnNews?.setOnClickListener {
            if (isShowingSports) {
                isShowingSports = false
                updateToggleVisuals(btnSports, btnNews)
                switchView(false)
                panelTitle?.text = "News"
            }
        }
    }

    private fun updateToggleVisuals(active: Button, inactive: Button) {
        active.setBackgroundResource(R.drawable.toggle_button_active)
        active.setTextColor(Color.WHITE)
        
        inactive.setBackgroundResource(R.drawable.toggle_button_inactive)
        inactive.setTextColor(Color.parseColor("#666666"))
    }

    private fun switchView(showSports: Boolean) {
        val sportsScroll = findViewById<ScrollView>(R.id.sports_scroll)
        val newsScroll = findViewById<ScrollView>(R.id.news_scroll)

        if (showSports) {
            sportsScroll?.visibility = android.view.View.VISIBLE
            newsScroll?.visibility = android.view.View.GONE
        } else {
            sportsScroll?.visibility = android.view.View.GONE
            newsScroll?.visibility = android.view.View.VISIBLE
        }
    }

    private fun updateWeatherUI() {
        try {
            val weatherIcon = findViewById<ImageView>(R.id.weather_icon)
            val tempView = findViewById<TextView>(R.id.temp_display)
            val conditionView = findViewById<TextView>(R.id.condition_display)
            val detailsView = findViewById<TextView>(R.id.weather_details)
            val cityView = findViewById<TextView>(R.id.city_name)

            tempView?.text = "72°"
            conditionView?.text = "Sunny, humidity 45%"
            detailsView?.text = "💨 12 mph | 👁️ 10 mi"
            cityView?.text = "Philadelphia, PA"
            weatherIcon?.setImageResource(R.drawable.ic_sun)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun updateSportsUI() {
        try {
            val sportsContainer = findViewById<LinearLayout>(R.id.sports_container)
            sportsContainer?.removeAllViews()

            addGameCard(sportsContainer, "Yankees vs Red Sox", "NYY", "BOS", 3, 1, "Top 7th")
            addGameCard(sportsContainer, "Lakers vs Warriors", "LAL", "GSW", 98, 105, "Q3 4:20")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun addGameCard(
        container: LinearLayout?,
        name: String,
        homeTeam: String,
        awayTeam: String,
        homeScore: Int,
        awayScore: Int,
        status: String
    ) {
        if (container == null) return
        
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 12 }
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.parseColor("#F5F5F5"))
        }

        val headerText = TextView(this).apply {
            text = name
            textSize = 14f
            setTextColor(Color.BLACK)
        }

        val scoreLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 8 }
        }

        val homeScoreTxt = TextView(this).apply {
            text = "$homeTeam $homeScore"
            textSize = 16f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.BLACK)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT).apply { weight = 1f }
        }

        val statusText = TextView(this).apply {
            text = status
            textSize = 12f
            setTextColor(Color.GRAY)
        }

        val awayScoreTxt = TextView(this).apply {
            text = "$awayScore $awayTeam"
            textSize = 16f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.BLACK)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT).apply { weight = 1f }
        }

        scoreLayout.addView(homeScoreTxt)
        scoreLayout.addView(statusText)
        scoreLayout.addView(awayScoreTxt)

        card.addView(headerText)
        card.addView(scoreLayout)
        container.addView(card)
    }

    private fun updateNewsUI() {
        try {
            val newsContainer = findViewById<LinearLayout>(R.id.news_container)
            newsContainer?.removeAllViews()

            addNewsItem(newsContainer, "Senate passes comprehensive infrastructure bill", "AP News")
            addNewsItem(newsContainer, "Tech stocks surge on AI earnings reports", "Reuters")
            addNewsItem(newsContainer, "Local school district announces new STEM program", "Philadelphia Inquirer")
            addNewsItem(newsContainer, "Weather patterns shift as climate warming accelerates", "NPR")
            addNewsItem(newsContainer, "Sports leagues report record fan engagement", "ESPN")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun addNewsItem(container: LinearLayout?, headline: String, source: String) {
        if (container == null) return

        val newsItem = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 12 }
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.parseColor("#FAFAFA"))
        }

        val headlineView = TextView(this).apply {
            text = headline
            textSize = 14f
            setTextColor(Color.BLACK)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

        val sourceView = TextView(this).apply {
            text = source
            textSize = 12f
            setTextColor(Color.GRAY)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 6 }
        }

        newsItem.addView(headlineView)
        newsItem.addView(sourceView)
        container.addView(newsItem)
    }
}
